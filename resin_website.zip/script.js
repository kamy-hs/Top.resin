
const cart = [];
const cartItemsEl = document.getElementById('cart-items');
const cartTotalEl = document.getElementById('cart-total');

document.querySelectorAll('.add-cart').forEach(btn => {
  btn.addEventListener('click', () => {
    const prod = btn.parentElement;
    const name = prod.dataset.name;
    const price = parseFloat(prod.dataset.price);
    
    cart.push({ name, price });
    updateCart();
  });
});

function updateCart() {
  cartItemsEl.innerHTML = '';
  const total = cart.reduce((sum, p) => sum + p.price, 0);
  cart.forEach(item => {
    const div = document.createElement('div');
    div.textContent = `${item.name} — £${item.price}`;
    cartItemsEl.appendChild(div);
  });
  cartTotalEl.textContent = total.toFixed(2);
}

document.getElementById('checkout').addEventListener('click', () => {
  alert(`Checkout - Total: £${cart.reduce((sum, p) => sum + p.price, 0).toFixed(2)}`);
});
